export default {
   'all': {
        'zh':'全选',
        'en':'All'
   }
}