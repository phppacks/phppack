export default {
   'hour': {
        'zh':'时',
        'en':'H'
   },
   'minute': {
        'zh':'分',
        'en':'M'
   },
   'second': {
        'zh':'秒',
        'en':'S'
   }
}