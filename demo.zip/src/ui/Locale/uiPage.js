export default {
   'page': {
        'zh':'页',
        'en':'page'
   },
   'total': {
        'zh':'总共',
        'en':'Total'
   },
   'go': {
        'zh':'跳转',
        'en':'Go'
   }
}