export default {
   'selectCol': {
        'zh':'显示的列',
        'en':'show col'
   },
   'search': {
        'zh':'搜索',
        'en':'search'
   }
}