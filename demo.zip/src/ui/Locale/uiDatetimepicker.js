import date from './uiDatepicker'
import time from './uiTimepicker'

export default Object.assign({},date,time)