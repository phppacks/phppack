export default {
   'confirm': {
        'zh':'确定',
        'en':'confirm'
   },
   'cancel': {
        'zh':'取消',
        'en':'cancel'
   }
}