import Components from './components'
import './style/default.less';
export default Components
