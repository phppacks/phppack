import Vue from 'vue'
import Router from '../phprouter/index'
import HelloWorld from '../components/HelloWorld'
import HelloDemo from '../components/HelloDemo'

Vue.use(Router)

const login = () => require.ensure("../components/login");

const reg = () => require.ensure("../components/reg");

export default new Router({
    routes: [{
            path: '/',
            name: 'HelloWorld',
            component: HelloWorld
        },
        {
            path: '/home',
            name: 'HelloDemo',
            component: HelloDemo,
            children: [
                { path: '/home/login', component:login },
                { path: '/home/reg', component:reg }
            ]

        }
    ]
})