import {warn} from '../util/warn';
import {extend} from '../util/misc';
export default {
    name: 'RouterView',
    functional: true,
    props: {
        name: {
            type: String,
            default: 'default'
        }
    },
    render (_, {props, children, parent, data}) {
        data.routerView = true;
        const h = parent.$createElement;
        const name = props.name;
        const route = parent.$route;
        const cache = parent._routerViewCache || (parent._routerViewCache = {});
        let depth = 0;
        let inactive = false;
        while (parent && parent._routerRoot !== parent) {
            if (parent.$vnode && parent.$vnode.data.routerView) {
                depth++;
            }
            if (parent._inactive) {
                inactive = true;
            }
            parent = parent.$parent;
        }
        data.routerViewDepth = depth;
        if (inactive) {
            return h(cache[name], data, children);
        }
        const matched = route.matched[depth];
        if (!matched) {
            cache[name] = null;
            return h();
        }

        const component = cache[name] = matched.components[name];

        data.registerRouteInstance = (vm, val) => {
            const current = matched.instances[name];
            if ((val && current !== vm) || (!val && current === vm)) {
                matched.instances[name] = val;
            }
        };
        ;
        (data.hook || (data.hook = {})).prepatch = (_, vnode) => {
            matched.instances[name] = vnode.componentInstance;
        };
        let propsToPass = data.props = resolveProps(route, matched.props && matched.props[name]);
        if (propsToPass) {
            propsToPass = data.props = extend({}, propsToPass);
            const attrs = data.attrs = data.attrs || {};
            for (const key in propsToPass) {
                if (!component.props || !(key in component.props)) {
                    attrs[key] = propsToPass[key];
                    delete propsToPass[key];
                }
            }
        }
        return h(component, data, children);
    }
};
function resolveProps (route, config) {
    switch (typeof config) {
        case 'undefined':
            return;
        case 'object':
            return config;
        case 'function':
            return config(route);
        case 'boolean':
            return config ? route.params : undefined;
        default:
            if ('development' !== 'production') {
                warn(false, `props in "${route.path}" is a ${typeof config}, ` + `expecting an object, function or boolean.`);
            }
    }
} 