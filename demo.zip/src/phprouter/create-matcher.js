import { resolvePath } from './util/path';
import { assert, warn } from './util/warn';
import { createRoute } from './util/route';
import { fillParams } from './util/params';
import { createRouteMap } from './create-route-map';
import { normalizeLocation } from './util/location';
export function createMatcher(routes, router) {
    const { pathList, pathMap, nameMap } = createRouteMap(routes);

    function addRoutes(routes) {
        createRouteMap(routes, pathList, pathMap, nameMap);
    }

    function match(raw, currentRoute, redirectedFrom) {
        const location = normalizeLocation(raw, currentRoute, false, router);

        if (location.path) {
            location.params = {};
            for (let i = 0; i < pathList.length; i++) {
                const path = pathList[i];
                const record = pathMap[path];
                if (matchRoute(record.regex, location.path, location.params)) {
                    return _createRoute(record, location, redirectedFrom);
                }
            }
        }
        return _createRoute(null, location);
    }

    function redirect(record, location) {
        const originalRedirect = record.redirect;
        let redirect = typeof originalRedirect === 'function' ? originalRedirect(createRoute(record, location, null, router)) : originalRedirect;
        if (typeof redirect === 'string') {
            redirect = {
                path: redirect
            };
        }
        if (!redirect || typeof redirect !== 'object') {
            if ('development' !== 'production') {
                warn(false, `invalid redirect option: ${JSON.stringify(redirect)}`);
            }
            return _createRoute(null, location);
        }
        const re = redirect;
        const { name, path } = re;
        let { query, hash, params } = location;
        query = re.hasOwnProperty('query') ? re.query : query;
        hash = re.hasOwnProperty('hash') ? re.hash : hash;
        params = re.hasOwnProperty('params') ? re.params : params;
        if (name) {
            const targetRecord = nameMap[name];
            return match({
                _normalized: true,
                name,
                query,
                hash,
                params
            }, undefined, location);
        } else {
            if (path) {
                const rawPath = resolveRecordPath(path, record);
                const resolvedPath = fillParams(rawPath, params, `redirect route with path "${rawPath}"`);
                return match({
                    _normalized: true,
                    path: resolvedPath,
                    query,
                    hash
                }, undefined, location);
            } else {
                if ('development' !== 'production') {
                    warn(false, `invalid redirect option: ${JSON.stringify(redirect)}`);
                }
                return _createRoute(null, location);
            }
        }
    }

    function alias(record, location, matchAs) {
        const aliasedPath = fillParams(matchAs, location.params, `aliased route with path "${matchAs}"`);
        const aliasedMatch = match({
            _normalized: true,
            path: aliasedPath
        });
        if (aliasedMatch) {
            const matched = aliasedMatch.matched;
            const aliasedRecord = matched[matched.length - 1];
            location.params = aliasedMatch.params;
            return _createRoute(aliasedRecord, location);
        }
        return _createRoute(null, location);
    }

    function _createRoute(record, location, redirectedFrom) {
        if (record && record.redirect) {
            return redirect(record, redirectedFrom || location);
        }
        if (record && record.matchAs) {
            return alias(record, location, record.matchAs);
        }
        return createRoute(record, location, redirectedFrom, router);
    }
    return {
        match,
        addRoutes
    };
};

function matchRoute(regex, path, params) {
    const m = path.match(regex);
    if (!m) {
        return false;
    } else {
        if (!params) {
            return true;
        }
    }
    for (let i = 1, len = m.length; i < len; ++i) {
        const key = regex.keys[i - 1];
        const val = typeof m[i] === 'string' ? decodeURIComponent(m[i]) : m[i];
        if (key) {
            params[key.name || 'pathMatch'] = val;
        }
    }
    return true;
}

function resolveRecordPath(path, record) {
    return resolvePath(path, record.parent ? record.parent.path : '/', true);
}