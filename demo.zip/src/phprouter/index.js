import {install} from './install';
import {inBrowser} from './util/dom';
import {cleanPath} from './util/path';
import {createMatcher} from './create-matcher';
import {normalizeLocation} from './util/location';
import {PHPPackRouter} from './history/phppack';
export default class VueRouter {
    constructor (options = {}) {
        this.app = null;
        this.apps = [];
        this.options = options;
        this.beforeHooks = [];
        this.resolveHooks = [];
        this.afterHooks = [];
        this.matcher = createMatcher(options.routes || [], this);
        this.history = new PHPPackRouter(this, options.base);
    }
    match (raw, current, redirectedFrom) {
        return this.matcher.match(raw, current, redirectedFrom);
    }
    init (app) {
        this.apps.push(app);
        if (this.app) {
            return;
        }
        this.app = app;
        const history = this.history;
        history.transitionTo(history.getCurrentLocation());
    }
    beforeEach (fn) {
        return registerHook(this.beforeHooks, fn);
    }
    beforeResolve (fn) {
        return registerHook(this.resolveHooks, fn);
    }
    afterEach (fn) {
        return registerHook(this.afterHooks, fn);
    }
    onReady (cb, errorCb) {
        this.history.onReady(cb, errorCb);
    }
    onError (errorCb) {
        this.history.onError(errorCb);
    }
    push (location, onComplete, onAbort) {
        this.history.push(location, onComplete, onAbort);
    }
    replace (location, onComplete, onAbort) {
        this.history.replace(location, onComplete, onAbort);
    }
    getMatchedComponents (to) {
        const route = to ? to.matched ? to : this.resolve(to).route : this.currentRoute;
        if (!route) {
            return [];
        }
        return [].concat.apply([], route.matched.map((m) => {
            return Object.keys(m.components).map((key) => {
                return m.components[key];
            });
        }));
    }
    resolve (to, current, append) {

        const location = normalizeLocation(to, current || this.history.current, append, this);
        const route = this.match(location, current);
        const fullPath = route.redirectedFrom || route.fullPath;
        const base = this.history.base;
        const href = createHref(base, fullPath, this.mode);
        return {
            location,
            route,
            href,
            normalizedTo: location,
            resolved: route
        };
    }
}
function registerHook (list, fn) {
    list.push(fn);
    return () => {
        const i = list.indexOf(fn);
        if (i > -1) {
            list.splice(i, 1);
        }
    };
}
function createHref (base, fullPath, mode) {
    var path = mode === 'hash' ? '#' + fullPath : fullPath;
    return base ? cleanPath(base + '/' + path) : path;
}
VueRouter.install = install;
VueRouter.version = '__VERSION__';
if (inBrowser && window.Vue) {
    window.Vue.use(VueRouter);
} 