import {History} from './base';
export class PHPPackRouter extends History {
    constructor (router, base) {
        super(router, base);
    }
    go (n) {
    }
    push (location, onComplete, onAbort) {
    }
    replace (location, onComplete, onAbort) {
    }
    ensureURL (push) {
    }
    getCurrentLocation () {
        var location = getLocation(this.base);
        return location;
    }
};
export function getLocation (base) {
    let path = decodeURI(window.location.pathname);
    if (base && path.indexOf(base) === 0) {
        path = path.slice(base.length);
    }
    return (path || '/') + window.location.search + window.location.hash;
}; 