import { _Vue } from '../install';
import { inBrowser } from '../util/dom';
import { runQueue } from '../util/async';
import { warn, isError } from '../util/warn';
import { START, isSameRoute } from '../util/route';
import { flatten, flatMapComponents, resolveAsyncComponents } from '../util/resolve-components';
export class History {
    constructor(router, base) {
        this.router = router;
        this.base = normalizeBase(base);
        this.current = START;
        this.pending = null;
        this.ready = false;
        this.readyCbs = [];
        this.readyErrorCbs = [];
        this.errorCbs = [];
    }
    listen(cb) {
        this.cb = cb;
    }
    onReady(cb, errorCb) {
        if (this.ready) {
            cb();
        } else {
            this.readyCbs.push(cb);
            if (errorCb) {
                this.readyErrorCbs.push(errorCb);
            }
        }
    }
    onError(errorCb) {
        this.errorCbs.push(errorCb);
    }
    transitionTo(location, onComplete, onAbort) {
        const route = this.router.match(location, this.current);
        this.confirmTransition(route, () => {
            this.updateRoute(route);
            onComplete && onComplete(route);
            this.ensureURL();
            if (!this.ready) {
                this.ready = true;
                this.readyCbs.forEach((cb) => {
                    cb(route);
                });
            }
        }, (err) => {
            if (onAbort) {
                onAbort(err);
            }
            if (err && !this.ready) {
                this.ready = true;
                this.readyErrorCbs.forEach((cb) => {
                    cb(err);
                });
            }
        });
    }
    confirmTransition(route, onComplete, onAbort) {
        const current = this.current;
        const abort = (err) => {
            if (isError(err)) {
                if (this.errorCbs.length) {
                    this.errorCbs.forEach((cb) => {
                        cb(err);
                    });
                } else {
                    warn(false, 'uncaught error during route navigation:');
                    console.error(err);
                }
            }
            onAbort && onAbort(err);
        };
        if (isSameRoute(route, current) && route.matched.length === current.matched.length) {
            this.ensureURL();
            return abort();
        }
        const { updated, deactivated, activated } = resolveQueue(this.current.matched, route.matched);
        const queue = [].concat(extractLeaveGuards(deactivated), this.router.beforeHooks, extractUpdateHooks(updated), activated.map((m) => {
            m.beforeEnter;
        }), resolveAsyncComponents(activated));
        this.pending = route;
        const iterator = (hook, next) => {
            if (this.pending !== route) {
                return abort();
            }
            try {;
                route = needToLoad(route);
                hook(route, current, (to) => {
                    if (to === false || isError(to)) {
                        this.ensureURL(true);
                        abort(to);
                    } else {
                        if (typeof to === 'string' || (typeof to === 'object' && (typeof to.path === 'string' || typeof to.name === 'string'))) {
                            abort();
                            if (typeof to === 'object' && to.replace) {
                                this.replace(to);
                            } else {
                                this.push(to);
                            }
                        } else {
                            next(to);
                        }
                    }
                });
            } catch (e) {
                abort(e);
            }
        };

        /**
         * 用于异步加载
         * @param  {[type]} route [description]
         * @return {[type]}       [description]
         */
        function needToLoad(route) {
            route.matched.map(function(value, index, array) {
                if (typeof value.components.default === 'function'){
                    var components  = value.components.default();
                    route.matched[index].components.default = components;
                }

            })
            return route;
        }
        runQueue(queue, iterator, () => {
            const postEnterCbs = [];
            const isValid = () => {
                this.current === route;
            };
            const enterGuards = extractEnterGuards(activated, postEnterCbs, isValid);
            const queue = enterGuards.concat(this.router.resolveHooks);
            runQueue(queue, iterator, () => {
                if (this.pending !== route) {
                    return abort();
                }
                this.pending = null;
                onComplete(route);
                if (this.router.app) {
                    this.router.app.$nextTick(() => {
                        postEnterCbs.forEach((cb) => {
                            cb();
                        });
                    });
                }
            });
        });
    }
    updateRoute(route) {
        const prev = this.current;
        this.current = route;
        this.cb && this.cb(route);
        this.router.afterHooks.forEach((hook) => {
            hook && hook(route, prev);
        });
    }
};

function normalizeBase(base) {
    if (!base) {
        if (inBrowser) {
            const baseEl = document.querySelector('base');
            base = (baseEl && baseEl.getAttribute('href')) || '/';
            base = base.replace(/^https?:\/\/[^\/]+/, '');
        } else {
            base = '/';
        }
    }
    if (base.charAt(0) !== '/') {
        base = '/' + base;
    }
    return base.replace(/\/$/, '');
}

function resolveQueue(current, next) {
    let i;
    const max = Math.max(current.length, next.length);
    for (i = 0; i < max; i++) {
        if (current[i] !== next[i]) {
            break;
        }
    }
    return {
        updated: next.slice(0, i),
        activated: next.slice(i),
        deactivated: current.slice(i)
    };
}

function extractGuards(records, name, bind, reverse) {
    const guards = flatMapComponents(records, (def, instance, match, key) => {
        const guard = extractGuard(def, name);
        if (guard) {
            return Array.isArray(guard) ? guard.map((guard) => {
                bind(guard, instance, match, key);
            }) : bind(guard, instance, match, key);
        }
    });
    return flatten(reverse ? guards.reverse() : guards);
}

function extractGuard(def, key) {
    if (typeof def !== 'function') {
        def = _Vue.extend(def);
    }
    return def.options[key];
}

function extractLeaveGuards(deactivated) {
    return extractGuards(deactivated, 'beforeRouteLeave', bindGuard, true);
}

function extractUpdateHooks(updated) {
    return extractGuards(updated, 'beforeRouteUpdate', bindGuard);
}

function bindGuard(guard, instance) {
    if (instance) {
        return function boundRouteGuard() {
            return guard.apply(instance, arguments);
        };
    }
}

function extractEnterGuards(activated, cbs, isValid) {
    return extractGuards(activated, 'beforeRouteEnter', (guard, _, match, key) => {
        return bindEnterGuard(guard, match, key, cbs, isValid);
    });
}

function bindEnterGuard(guard, match, key, cbs, isValid) {
    return function routeEnterGuard(to, from, next) {
        return guard(to, from, (cb) => {
            next(cb);
            if (typeof cb === 'function') {
                cbs.push(() => {
                    poll(cb, match.instances, key, isValid);
                });
            }
        });
    };
}

function poll(cb, instances, key, isValid) {
    if (instances[key] && !instances[key]._isBeingDestroyed) {
        cb(instances[key]);
    } else {
        if (isValid()) {
            setTimeout(() => {
                poll(cb, instances, key, isValid);
            }, 16);
        }
    }
}